//
//  Product_Distance.swift
//  AlSouq
//
//  Created by Lola M on 15/01/2022.
//

import Foundation


struct Product_Distance : Identifiable, Codable {
    
    var id: String
    var name: String
    var category: String
    var createdBy: String
    var createdID: String
    var price: String
    var image: String
    var lat: Double
    var long: Double
    var distance: Double
    var description: String
    var note: String
    
}
