//
//  Product.swift
//  AlSouq
//
//  Created by Lola M on 12/01/2022.
//

import Foundation
import Firebase


class Product: Identifiable, Codable {
    
    var id: String
    var name: String
    var category: String
    var createdBy: String
    var createdID: String
    var price: String
    var image: String
    var lat: Double
    var long: Double
    var description: String
    var note: String
    var available: Bool?
    
    init (id_value: String, name_value: String, category_value:String, created:String,createId:String, price_value:String, image_value:String, lat: Double, long: Double,description_value:String,note_value:String, available:Bool){
        self.id = id_value
        self.name = name_value
        self.category = category_value
        self.createdBy = created
        self.createdID = createId
        self.price = price_value
        self.image = image_value
        self.lat = lat
        self.long = long
        self.description  = description_value
        self.note = note_value
        self.available = available
    }
    
}
