//
//  ChatRoom.swift
//  AlSouq
//
//  Created by Lola M on 17/01/2022.
//

import Foundation

struct ChatRoom: Codable {
    
    var channelID: String
    var users: [String]
    
}
