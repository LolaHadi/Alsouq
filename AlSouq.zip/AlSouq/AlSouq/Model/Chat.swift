//
//  Chat.swift
//  AlSouq
//
//  Created by Lola M on 14/01/2022.
//

import Foundation
import Firebase
import CodableFirebase


struct Chat: Codable {
    
    var id: String
    var channelID: String
    var messageId: String
    var senderId: String
    var displayName: String
    var sentDate: Timestamp
    var kind: String
    var message: String
    var users : [String]
    
}


extension DocumentReference: DocumentReferenceType {}
extension GeoPoint: GeoPointType {}
extension FieldValue: FieldValueType {}
extension Timestamp: TimestampType {}
