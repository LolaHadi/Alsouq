//
//  Sender.swift
//  AlSouq
//
//  Created by Lola M on 13/01/2022.
//

import Foundation
import MessageKit

struct Sender: SenderType {
    var senderId: String
    var displayName: String
}
