//
//  Constants.swift
//  AlSouq
//
//  Created by Lola M on 11/01/2022.
//

import Foundation

var userUUID = ""
var currentUserProfile: Profile?
var CategoryList = [Category]()


let AgriculturalCrops = [SubCategory(name: "season"),SubCategory(name: "vegetables"),SubCategory(name: "fruits"),SubCategory(name: "leafy vegetables"),SubCategory(name: "cereals and flour"),SubCategory(name: "aromatic plants"),SubCategory(name: "agricultural seedlings")]

let Livestock = [SubCategory(name: "livestock"),SubCategory(name: "fish")]

let dates = [SubCategory(name: "Subcategory1"),SubCategory(name: "Subcategory2"),SubCategory(name: "Subcategory3")]

let OrganicProducts
 = [SubCategory(name: "Dairy products"),SubCategory(name: "ghee"),SubCategory(name: "Honey"),SubCategory(name: "vegetable oils")]
let HerbsAndCoffee
 = [SubCategory(name: "Spices"),SubCategory(name: "coffee beans"),SubCategory(name: "herbs")]

let Crafts = [SubCategory(name: "blacksmithing"),SubCategory(name: "carpentry"),SubCategory(name: "stone pots"),SubCategory(name: "copper pots"),SubCategory(name: "the wood"),SubCategory(name: "Weaving and Yarn"),SubCategory(name: "leather"),SubCategory(name: "Tools and machines"),SubCategory(name: "Furniture")]

let FabricsAndFashion
 = [SubCategory(name: "fabrics"),SubCategory(name: "local fashion"),SubCategory(name: "ornaments"),SubCategory(name: "the shoes")]

let PerfumesAndSpices
 = [SubCategory(name: "incense"),SubCategory(name: "Oil Perfumes"),SubCategory(name: "oriental perfumes"),SubCategory(name: "Rose water")]

let  seaAndFishing
 = [SubCategory(name: "Wooden boats"),SubCategory(name: "Fishing nets"),SubCategory(name: "pearl"),SubCategory(name: "fish")]

let LocalDishes = [SubCategory(name: "Subcategory1"),SubCategory(name: "Subcategory2"),SubCategory(name: "Subcategory3")]


struct Category {
  var name:String
  var subCategory:[SubCategory]
}
struct SubCategory {
    var name:String
}

class Utilities {
   static func getCategories() -> [Category]{
       let categories =  [Category(name: "Agricultural crops", subCategory: AgriculturalCrops),Category(name: "Crafts", subCategory: Crafts),Category(name: "Dates", subCategory: dates),Category(name: "Local dishes", subCategory: LocalDishes),Category(name: "Fabrics and fashion", subCategory: FabricsAndFashion),Category(name: "Herbs", subCategory: HerbsAndCoffee),Category(name: "Livestock", subCategory: Livestock),Category(name: "Organic products", subCategory: OrganicProducts),Category(name: "Perfume", subCategory: PerfumesAndSpices),Category(name: "Sea fishing", subCategory: seaAndFishing)]
       return categories
    }
}
