//
//  Profile.swift
//  AlSouq
//
//  Created by Lola M on 13/01/2022.
//

import Foundation


class Profile: Identifiable, Codable {
    
    var uid: String
    var  image: String?
    var name: String?
    var number: String
    var rate: Double?
    var purchases: [String]?
    var wish: [String]?
    var fav: [String]?
    var channel: [String]?
    
    
    init(id: String, image: String, name: String, phone: String, rate: Double, purchase: [String], wish: [String], channelTitle: [String]) {
        self.uid = id
        self.image = image
        self.name = name
        self.number = phone
        self.rate = rate
        self.purchases = purchase
        self.wish = wish
        self.channel = channelTitle
    }
}
