//
//  Review.swift
//  AlSouq
//
//  Created by SLola M on 16/01/2022.
//

import Foundation


struct Review: Codable {
    
    var id: String
    var productID: String
    var sellerID: String
    var buyerID: String
    var buyerName: String
    var rate: Double
    var comment: String
    var status: Bool
    
}
