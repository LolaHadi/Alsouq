//
//  Accessibility.swift
//  AlSouq
//
//  Created by Lola M on 11/01/2022.
//

import Foundation


enum Accessibility {
    
    public static let selectCountryPicker = "Select country picker"
    public static let searchCountry = "Search country name here.."
    public static let cross = "Cross button"
    
}
