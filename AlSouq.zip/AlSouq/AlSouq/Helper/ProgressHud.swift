//
//  ProgressHud.swift
//  AlSouq
//
//  Created by Irfan on 1/23/22.
//

import Foundation

import Foundation
import UIKit
import MBProgressHUD

class ProgressHUD: MBProgressHUD {
    
    private static var sharedView: ProgressHUD!
    
    @discardableResult
    func mode(mode: MBProgressHUDMode) -> ProgressHUD {
        self.mode = mode
        return self
    }
    
    @discardableResult
    func animationType(animationType: MBProgressHUDAnimation) -> ProgressHUD {
        self.animationType = animationType
        return self
    }
    
    @discardableResult
    func backgroundViewStyle(style: MBProgressHUDBackgroundStyle) -> ProgressHUD {
        self.backgroundView.style = style
        return self
    }
    
    
   class func progress(text: String)  {
        ProgressHUD.sharedView.label.text = text
    }
    
    class func ProgressHudSharedView() -> ProgressHUD {
        return ProgressHUD.sharedView
    }
    
    @discardableResult
    class func present(animated: Bool = true, view: UIView? = nil,mview: UIViewController) -> Bool {

            if sharedView != nil {
                sharedView.hide(animated: false)
            }
            if let view =  view {
                
                sharedView = ProgressHUD.showAdded(to: view, animated: true)
            }
            else {
                if let view = UIApplication.shared.windows.first?.rootViewController?.view {
                    sharedView = ProgressHUD.showAdded(to: view, animated: true)
                }
            }
            return true
            
    }
    
    class func dismiss(animated: Bool = true ) {
        if sharedView != nil {
            sharedView.hide(animated: true)
        }
    }

}

 
