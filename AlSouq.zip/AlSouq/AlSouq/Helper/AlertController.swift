//
//  AlertController.swift
//  AlSouq
//
//  Created by Irfan on 1/25/22.
//

import Foundation

import Foundation
import UIKit
struct AlertController {
    
    static func present(buttonTitle: String = "Ok", title: String = "Alert", _ message: String, _ completion: (() -> Void)? = nil)  {
        
        let alert = UIAlertController(title: title, message: message, preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: buttonTitle, style: .default, handler: { (action) in
            completion?()
        }))
        if let rootController = UIApplication.shared.windows.first?.rootViewController {
             rootController.present(alert, animated: true, completion: nil)
        }
    }
    
    static func confirmation(vc: UIViewController? = nil ,done:String =  "Ok" ,title: String = "Alert", _ message: String, _ confirm: (() -> Void)? = nil)  {
        
        let alert = UIAlertController(title: title, message: message, preferredStyle: UIAlertController.Style.alert)
        
        alert.addAction(UIAlertAction(title: "Cancel", style: .default, handler: { (action) in
            print("cancel tapped")
        }))
        
        alert.addAction(UIAlertAction(title: done, style: .default, handler: { (action) in
            confirm?()
        }))
        
        if let viewController = vc {
          viewController.present(alert, animated: true, completion: nil)
          return
        }
        if let rootController = UIApplication.shared.windows.first?.rootViewController {
            rootController.present(alert, animated: true, completion: nil)
            return
        }
    }
}
