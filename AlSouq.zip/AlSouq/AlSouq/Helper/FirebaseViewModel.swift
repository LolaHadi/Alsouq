//
//  FirebaseViewModel.swift
//  AlSouq
//
//  Created by Lola M on 11/01/2022.
//

import Foundation
import SwiftUI
import FirebaseStorage
import FirebaseAuth
import Firebase
import CodableFirebase

class FirebaseViewModel {
    
    let fb = Firestore.firestore()
    
    func SaveImage(Title : String, selectedImage : UIImage, completion: @escaping (_ uploadImageUrl: String?,_ Status : Bool,_ errorMsg : String?)->()) {
        
        let storage  = Storage.storage()
        let storageRef = storage.reference()
        var imageData = Data()
        let uploadMetadata = StorageMetadata()
        uploadMetadata.contentType = "image/jpeg"
        
        imageData = selectedImage.jpegData(compressionQuality: 0.8)!
        
        // ******* Create Image Reference ************
        let uploadImageRef = storageRef.child((UUID().uuidString)).child(Title)
        
        //  upload the image file to respective path
        
        uploadImageRef.putData(imageData, metadata: uploadMetadata) { (metaData, err) in
            if err  != nil {
                completion(nil, false, err?.localizedDescription)
            } else {
                uploadImageRef.downloadURL(completion: { (downloadUrl, downlodError) in
                    if downlodError == nil {
                        completion(downloadUrl?.absoluteString,true,nil)
                    } else {
                        completion(nil, false, err?.localizedDescription)
                    }
                })
            }
        }
    }
    
    
    func SaveThumbnailImage(Title: String, selectedImage: UIImage, completion: @escaping (_ uploadImageUrl: String?,_ Status: Bool,_ errorMsg: String?)->()) {
        
        let storage  = Storage.storage()
        let storageRef = storage.reference()
        var imageData = Data()
        let uploadMetadata = StorageMetadata()
        
        uploadMetadata.contentType = "image/jpeg"
        imageData = selectedImage.jpegData(compressionQuality: 0.3)!
        
        // ******* Create Image Reference ************
        let uploadImageRef = storageRef.child((Auth.auth().currentUser?.uid)!).child("\(Title)_thumbail")
        
        //  upload the image file to respective path
        
        uploadImageRef.putData(imageData, metadata: uploadMetadata) { (metaData, err) in
            
            if err  != nil {
                completion(nil, false, err?.localizedDescription)
            } else {
                uploadImageRef.downloadURL(completion: { (downloadUrl, downlodError) in
                    if downlodError == nil {
                        completion(downloadUrl?.absoluteString,true,nil)
                    } else {
                        completion(nil, false, err?.localizedDescription)
                    }
                })
            }
        }
    }
    
    
    func GetChatRoom(completion: @escaping (_ chat: [ChatRoom],_ Status : Bool,_ errorMsg : String?)->()) {
        
        var getValues = [ChatRoom]()
        fb.collection("Chatroom").whereField("users", arrayContainsAny: [userUUID]).getDocuments { snap, err in
            if err == nil {
                let values = snap?.documents
                values?.forEach({doc in
                    let value  = try! FirestoreDecoder().decode(ChatRoom.self, from: doc.data())
                    getValues.append(value)
                })
                completion(getValues,true, nil)
            }
        }
    }
    
    
    func GetConversation(channel: String, completion: @escaping (_ chat: [Chat],_ Status : Bool,_ errorMsg : String?)->()) {
        
        var getValues = [Chat]()
        //        let fs = Firestore.firestore()
        self.fb.collection("Chatroom").document(channel).collection("Chats").getDocuments { chat_Snap, chat_err in
            if chat_err == nil {
                guard let fetchData = chat_Snap?.documents else { return }
                fetchData.forEach({ doc in
                    let value  = try! FirestoreDecoder().decode(Chat.self, from: doc.data())
                    getValues.append(value)
                })
                completion(getValues,true, nil)
            } else {
                completion([],false,(chat_err?.localizedDescription)!)
            }
        }
    }
    
    
    func GetProfile(completion: @escaping (_ user: Profile?,_ Status : Bool,_ errorMsg : String?)->()) {
        
        print(userUUID)
        fb.collection("Users").document(userUUID).getDocument { snap, err in
            if err == nil {
                guard let fetchData = snap?.data() else { return }
                let value  = try! FirestoreDecoder().decode(Profile.self, from: fetchData)
                currentUserProfile = value
                completion(value,true, nil)
            } else {
                completion(nil,false,(err?.localizedDescription)!)
            }
        }
    }
    
    
    func UserProduct(id: String, completion: @escaping (_ products: [Product],_ Status: Bool,_ errorMsg: String?)->()) {
        
        var getValues = [Product]()
        fb.collection("Products").whereField("createdID", isEqualTo: id).getDocuments { snap, err in
            if err == nil {
                let fetchData = snap?.documents
                fetchData?.forEach({ doc in
                    let value  = try! FirestoreDecoder().decode(Product.self, from: doc.data())
                    getValues.append(value)
                })
                completion(getValues,true, nil)
            } else {
                completion([],false,(err?.localizedDescription)!)
            }
        }
    }
    
    
    func AllProduct(completion: @escaping (_ products: [Product],_ Status : Bool,_ errorMsg : String?)->()) {
        
        var getValues = [Product]()
        fb.collection("Products").whereField("available", isEqualTo: true).getDocuments { snap, err in
            if err == nil {
                let fetchData = snap?.documents
                fetchData?.forEach({ doc in
                    let value  = try! FirestoreDecoder().decode(Product.self, from: doc.data())
                    getValues.append(value)
                })
                completion(getValues,true, nil)
            } else {
                completion([],false,(err?.localizedDescription)!)
            }
        }
    }
    
    
    func ProductByCategory(title: String, completion: @escaping (_ products: [Product],_ Status: Bool,_ errorMsg: String?)->()) {
        
        var getValues = [Product]()
        fb.collection("Products").whereField("category", isEqualTo: title).whereField("available", isEqualTo: true).getDocuments { snap, err in
            
            if err == nil {
                let fetchData = snap?.documents
                fetchData?.forEach({ doc in
                    let value  = try! FirestoreDecoder().decode(Product.self, from: doc.data())
                    getValues.append(value)
                })
                completion(getValues,true, nil)
            } else {
                completion([],false,(err?.localizedDescription)!)
            }
        }
    }
    
    
    func getPurchase(completion: @escaping (_ products: [Product],_ Status : Bool,_ errorMsg : String?)->()) {
        
        var getValues = [Product]()
        guard let purchasedList = currentUserProfile?.purchases else { return }
        
        purchasedList.forEach { uid in
            print(uid)
            fb.collection("Products").document(uid).getDocument { snap, err in
                if err == nil {
                    guard let fetchData = snap?.data() else { return }
                    let value  = try! FirestoreDecoder().decode(Product.self, from: fetchData)
                    getValues.append(value)
                    completion(getValues,true, nil)
                } else {
                    completion([],false,(err?.localizedDescription)!)
                }
            }
        }
    }
    
    
    func getSeller(completion: @escaping (_ products: [Product],_ Status : Bool,_ errorMsg : String?)->()) {
        
        var getValues = [Product]()
        fb.collection("Products").whereField("createdID", isEqualTo: userUUID).getDocuments { snap, err in
            if err == nil {
                let fetchData = snap?.documents
                fetchData?.forEach({ doc in
                    let value  = try! FirestoreDecoder().decode(Product.self, from: doc.data())
                    getValues.append(value)
                })
                completion(getValues,true, nil)
            } else {
                completion([],false,(err?.localizedDescription)!)
            }
        }
    }
    
    
    func getFav(completion: @escaping (_ products: [Product],_ Status : Bool,_ errorMsg : String?)->()) {
        
        var getValues = [Product]()
        guard let favList = currentUserProfile?.fav else { return }
        
        favList.forEach { uid in
            print(uid)
            
            fb.collection("Products").document(uid).getDocument { snap, err in
                if err == nil {
                    guard let fetchData = snap?.data() else { return }
                    
                    let value  = try! FirestoreDecoder().decode(Product.self, from: fetchData)
                    getValues.append(value)
                    completion(getValues,true, nil)
                } else {
                    completion([],false,(err?.localizedDescription)!)
                }
            }
        }
    }
    
    
    func getWish(completion: @escaping (_ products: [Product],_ Status : Bool,_ errorMsg : String?)->()) {
        
        var getValues = [Product]()
        guard let wishList = currentUserProfile?.wish else { return }
        
        wishList.forEach { uid in
            print(uid)
            fb.collection("Products").document(uid).getDocument { snap, err in
                if err == nil {
                    guard let fetchData = snap?.data() else { return }
                    let value  = try! FirestoreDecoder().decode(Product.self, from: fetchData)
                    
                    getValues.append(value)
                    completion(getValues,true, nil)
                } else {
                    completion([],false,(err?.localizedDescription)!)
                }
            }
        }
    }
    
    
    func getUserProfile(id :String, completion: @escaping (_ profile: Profile?,_ Status : Bool,_ errorMsg : String?)->()){
        
        fb.collection("Users").document(id).getDocument { snap, err in
            if err == nil {
                guard let fetchData = snap?.data() else { return }
                
                let value  = try! FirestoreDecoder().decode(Profile.self, from: fetchData)
                
                completion(value,true, nil)
            } else {
                completion(nil, false,err?.localizedDescription)
            }
        }
    }
    
    
    func getReview(id :String, completion: @escaping (_ review: [Review],_ Status: Bool,_ errorMsg: String?)->()) {
        
        var result = [Review]()
        
        fb.collection("Review").whereField("status", isEqualTo: true).whereField("sellerID", isEqualTo: userUUID).getDocuments { snap, err in
            
            if err == nil {
                guard let fetchData = snap?.documents  else { return }
                fetchData.forEach { doc in
                    let value  = try! FirestoreDecoder().decode(Review.self, from: doc.data())
                    result.append(value)
                }
                completion(result,true, nil)
            } else {
                completion([], false,err?.localizedDescription)
            }
        }
    }
    
    
    func getRequest(id :String, completion: @escaping (_ review: [Review],_ Status: Bool,_ errorMsg: String?)->()) {
        
        var result = [Review]()
        
        fb.collection("Review").whereField("sellerID", isEqualTo: userUUID).whereField("status", isEqualTo: false).getDocuments { snap, err in
            
            if err == nil {
                guard let fetchData = snap?.documents  else { return }
                
                fetchData.forEach { doc in
                    let value  = try! FirestoreDecoder().decode(Review.self, from: doc.data())
                    result.append(value)
                }
                completion(result,true, nil)
            } else {
                completion([], false,err?.localizedDescription)
            }
        }
    }
}

