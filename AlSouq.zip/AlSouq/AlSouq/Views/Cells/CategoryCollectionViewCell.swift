//
//  CategoryCollectionViewCell.swift
//  AlSouq
//
//  Created by Irfan on 1/25/22.
//

import Foundation
import UIKit
class CategoryCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var catergoryImage: UIImageView!
    @IBOutlet weak var mainView: UIView!
    @IBOutlet weak var title: UILabel!
    
    var selectedCell: Bool = false {
        didSet {
            self.mainView.backgroundColor = selectedCell ? .red : .white
        }
    }
    
}
