//
//  SubCategoryCollectionViewCell.swift
//  AlSouq
//
//  Created by Lola M on 13/01/2022.
//

import UIKit

class SubCategoryCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var catergoryImage: UIImageView!
    @IBOutlet weak var title: UILabel!
    @IBOutlet weak var mainView: UIView?
    
}
