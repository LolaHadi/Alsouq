//
//  CategoryTableViewCell.swift
//  AlSouq
//
//  Created by Lola M on 11/01/2022.
//

import UIKit

class CategoryTableViewCell: UITableViewCell {

    @IBOutlet weak var catergoryImage: UIImageView!
    @IBOutlet weak var title: UILabel!
    
}
