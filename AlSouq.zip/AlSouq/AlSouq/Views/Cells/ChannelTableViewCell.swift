//
//  ChannelTableViewCell.swift
//  AlSouq
//
//  Created by Lola M on 15/01/2022.
//

import UIKit

class ChannelTableViewCell: UITableViewCell {

    @IBOutlet weak var userDP: UIImageView!
    @IBOutlet weak var message: UILabel!
    @IBOutlet weak var sellerName: UILabel!

}
