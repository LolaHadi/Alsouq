//
//  ReviewTableCell.swift
//  AlSouq
//
//  Created by Lola M on 16/01/2022.
//

import UIKit
import HCSStarRatingView

class ReviewTableCell: UITableViewCell {

    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var reviewText: UITextView!
    @IBOutlet weak var rateStat: HCSStarRatingView!

}
