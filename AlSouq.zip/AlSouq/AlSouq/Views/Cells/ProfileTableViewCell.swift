//
//  ProfileTableViewCell.swift
//  AlSouq
//
//  Created by Lola M on 1/19/22.
//

import UIKit

class ProfileTableViewCell: UITableViewCell {

    @IBOutlet weak var foodImage: UIImageView!
    @IBOutlet weak var title: UILabel!
    @IBOutlet weak var sellerName: UILabel!
    @IBOutlet weak var distance: UILabel!
    @IBOutlet weak var price: UILabel!
    @IBOutlet weak var heartBtn: UIButton!
    @IBOutlet weak var chatBtn: UIButton!
    @IBOutlet weak var statusBtn: UIButton!

}
