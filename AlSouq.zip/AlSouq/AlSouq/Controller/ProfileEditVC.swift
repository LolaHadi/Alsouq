//
//  ProfileEditVC.swift
//  Alsouq
//
//  Created by Lola M on 1/15/22.
//

import UIKit
import Firebase


class ProfileEditVC: UIViewController {
    
    
    //MARK: OUTLETS
    @IBOutlet weak var profileImage: Custom_ImageView!
    @IBOutlet weak var NameTF: UITextField!
    @IBOutlet weak var numberTF: UITextField!
    
    
    //MARK:  VARIABLES
    let imagePicker = UIImagePickerController()
    var selectedImage : UIImage = UIImage(systemName: "person.circle")!
    
    
    //MARK:  FUNCTIONS
    func openCamera() {
        if UIImagePickerController.isSourceTypeAvailable(UIImagePickerController.SourceType.camera) {
            let imagePicker = UIImagePickerController()
            imagePicker.delegate = self
            imagePicker.sourceType = UIImagePickerController.SourceType.camera
            imagePicker.allowsEditing = false
            self.present(imagePicker, animated: true, completion: nil)
        } else {
            let alert  = UIAlertController(title: "Warning", message: "You don't have camera", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
    }
    
    
    func openGallery() {
        if UIImagePickerController.isSourceTypeAvailable(UIImagePickerController.SourceType.photoLibrary){
            
            imagePicker.delegate = self
            imagePicker.allowsEditing = true
            imagePicker.sourceType = UIImagePickerController.SourceType.photoLibrary
            self.present(imagePicker, animated: true, completion: nil)
        } else {
            let alert  = UIAlertController(title: "Warning", message: "You don't have permission to access gallery.", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
    }
    
    
    //MARK:  VIEW FUNCTIONS
    override func viewDidLoad() {
        super.viewDidLoad()
        imagePicker.delegate = self
        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(imagePickerBtnAction))
        profileImage.addGestureRecognizer(tapGestureRecognizer)
        profileImage.isUserInteractionEnabled = true
        
        NameTF.text = currentUserProfile?.name ?? ""
        numberTF.text = (currentUserProfile?.number ?? "")
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }
    
    
    
    //MARK:  OUTLET ACTION
    @IBAction func backBtnAction(_ sender: Any) {
        self.dismiss(animated: true)
    }
    
    @IBAction func deleteBtnAction(_ sender: Any) {
        let fs = Firestore.firestore()
        fs.collection("Users").document(userUUID).delete()
        
        UserDefaults.standard.set(false, forKey: "Auth")
        UserDefaults.standard.set("", forKey: "uid")
        
        let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "Initial")
        self.present(vc, animated: false)
    }
    
    @IBAction func logoutBtnAction(_ sender: Any) {
        do {
            try! Auth.auth().signOut()
            
            UserDefaults.standard.set(false, forKey: "Auth")
            UserDefaults.standard.set("id", forKey: "uid")
            
            let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "Initial")
            self.present(vc, animated: false)
        } catch {
            print(error)
        }
    }
    
    
    @objc func imagePickerBtnAction(selectedButton: UIButton) {
        let alert = UIAlertController(title: "Choose Image", message: nil, preferredStyle: .actionSheet)
        alert.addAction(UIAlertAction(title: "Camera", style: .default, handler: { _ in
            self.openCamera()
        }))
        alert.addAction(UIAlertAction(title: "Gallery", style: .default, handler: { _ in
            self.openGallery()
        }))
        alert.addAction(UIAlertAction.init(title: "Cancel", style: .cancel, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
    
    
    
    @IBAction func addBtnAction(_ sender: Any) {
        
        if NameTF.text?.isEmpty == false {
            let fb = Firestore.firestore()
            let saveImageVM = FirebaseViewModel()
            saveImageVM.SaveImage(Title: NameTF.text!, selectedImage: self.selectedImage) { uploadImageUrl, Status, errorMsg in
                if Status {
                    let dict = [
                        "uid":userUUID,
                        "image":(uploadImageUrl)!,
                        "name": self.NameTF.text!,
                        "number": self.numberTF.text!,
                        
                    ] as [String:Any]
                    
                    print(dict)
                    fb.collection("Users").document(userUUID).updateData(dict)
                    currentUserProfile!.image = (uploadImageUrl ?? "")
                    currentUserProfile!.name = self.NameTF.text!
                    
                    self.dismiss(animated: true)
                } else {
                    print("\(errorMsg)")
                }
            }
        }
    }
}




//MARK:  EXTENSION
extension ProfileEditVC: UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        picker.dismiss(animated: true, completion: nil)
        guard let originalImage = info[UIImagePickerController.InfoKey.originalImage] as? UIImage else {
            return
        }
        //for image rotation
        let image =  originalImage.upOrientationImage()
        profileImage.image = image
        self.selectedImage = image!
    }
    
}


