//
//  AddProductVC.swift
//  Alsouq
//
//  Created by Lola M on 1/15/22.
//

import UIKit
import LocationPicker
import CoreLocation
import MapKit
import Firebase


class AddProductVC: UIViewController {
    
    //MARK: OUTLETS
    @IBOutlet weak var productNameTF: UITextField!
    @IBOutlet weak var descriptionTF: UITextView!
    @IBOutlet weak var categoryTF: UITextField!
    @IBOutlet weak var subCategoryTF: UITextField!
    @IBOutlet weak var priceTF: UITextField!
    @IBOutlet weak var productImage: UIImageView!
    @IBOutlet weak var locationTF: UITextField!
    @IBOutlet weak var noteTF: UITextView!
    //MARK:  VARIABLES
    var categoryList = [Category]()
    var subCategoryList = [SubCategory]()
    var addProtocol : addProdProtocol!
    var pickerView : UIPickerView! = UIPickerView()
    var subPickerView : UIPickerView! = UIPickerView()
    var selectedLat = 0.0
    var selectLong = 0.0
    var selectedImage : UIImage  = UIImage(named: "upload")!
    let imagePicker = UIImagePickerController()
    var location: Location? {
        didSet {
            locationTF.text = location.flatMap({ $0.title }) ?? "No location selected"
            selectedLat = location.flatMap({$0.location.coordinate.latitude}) ?? 0.0
            selectLong = location.flatMap({$0.location.coordinate.longitude}) ?? 0.0
        }
    }
    
    var locationManager = CLLocationManager()
    var lat  = 0.0
    var  long = 0.0
    
    
    //MARK:  VIEW Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.isNavigationBarHidden = true
        
        pickerView.dataSource = self
        pickerView.delegate = self
        
        subPickerView.dataSource = self
        subPickerView.delegate = self
        
        categoryTF.delegate = self
        subCategoryTF.delegate = self
        imagePicker.delegate = self
        

        locationManager.delegate = self;
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.requestAlwaysAuthorization()
        locationManager.startUpdatingLocation()
        productImage.image = selectedImage
        
        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(imagePickerBtnAction))
        productImage.addGestureRecognizer(tapGestureRecognizer)
        productImage.isUserInteractionEnabled = true
        
        categoryList = Utilities.getCategories()
    }
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidAppear(animated)
        self.navigationController?.isNavigationBarHidden = false
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.isNavigationBarHidden = true
    }
    
    //MARK:  FUNCTIONS
    func openCamera() {
        if UIImagePickerController.isSourceTypeAvailable(UIImagePickerController.SourceType.camera) {
            let imagePicker = UIImagePickerController()
            imagePicker.delegate = self
            imagePicker.sourceType = UIImagePickerController.SourceType.camera
            imagePicker.allowsEditing = false
            self.present(imagePicker, animated: true, completion: nil)
        } else {
            let alert  = UIAlertController(title: "Warning", message: "You don't have camera", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
    }
    
    
    func openGallery() {
        if UIImagePickerController.isSourceTypeAvailable(UIImagePickerController.SourceType.photoLibrary){
            
            imagePicker.delegate = self
            imagePicker.allowsEditing = true
            imagePicker.sourceType = UIImagePickerController.SourceType.photoLibrary
            self.present(imagePicker, animated: true, completion: nil)
        } else {
            let alert  = UIAlertController(title: "Warning", message: "You don't have permission to access gallery.", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
    }
    
    
    
    
    

    //MARK:  OUTLET ACTION
    @IBAction func backBtnAction(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @objc func imagePickerBtnAction(selectedButton: UIButton) {
        let alert = UIAlertController(title: "Choose Image", message: nil, preferredStyle: .actionSheet)
        alert.addAction(UIAlertAction(title: "Camera", style: .default, handler: { _ in
            self.openCamera()
        }))
        alert.addAction(UIAlertAction(title: "Gallery", style: .default, handler: { _ in
            self.openGallery()
        }))
        alert.addAction(UIAlertAction.init(title: "Cancel", style: .cancel, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
    
    @IBAction func locationBtnAction(_ sender: Any) {
        //        let locationPicker = LocationPickerViewController()
        //
        //        // you can optionally set initial location
        //        let placemark = MKPlacemark(coordinate: CLLocationCoordinate2D(latitude: self.lat, longitude: self.long), addressDictionary: nil)
        //        let location = Location(name: "1 Infinite Loop, Cupertino", location: nil, placemark: placemark)
        //        locationPicker.location = location
        //
        //        // button placed on right bottom corner
        //        locationPicker.showCurrentLocationButton = true // default: true
        //
        //        // default: navigation bar's `barTintColor` or `UIColor.white`
        //        locationPicker.currentLocationButtonBackground = .blue
        //
        //        // ignored if initial location is given, shows that location instead
        //        locationPicker.showCurrentLocationInitially = true // default: true
        //
        //        locationPicker.mapType = .standard // default: .Hybrid
        //
        //        // for searching, see `MKLocalSearchRequest`'s `region` property
        //        locationPicker.useCurrentLocationAsHint = true // default: false
        //
        //        locationPicker.searchBarPlaceholder = "Search places" // default: "Search or enter an address"
        //
        //        locationPicker.searchHistoryLabel = "Previously searched" // default: "Search History"
        //
        //        // optional region distance to be used for creation region when user selects place from search results
        //        locationPicker.resultRegionDistance = 500 // default: 600
        //
        //        locationPicker.completion = { location in
        //            // do some awesome stuff with location
        //            self.selectedLat = location?.location.coordinate.latitude ?? 0.0
        //            self.selectLong = location?.location.coordinate.longitude ?? 0.0
        //
        //            self.locationTF.text = "lat:\(self.selectedLat) & long:\(self.selectLong)"
        //        }
        
        //        self.performSegue(withIdentifier: "Location", sender: nil)
        //        navigationController?.pushViewController(locationPicker, animated: true)
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "Location" {
            let locationPicker = segue.destination as! LocationPickerViewController
            locationPicker.location = location
            locationPicker.showCurrentLocationButton = true
            locationPicker.useCurrentLocationAsHint = true
            locationPicker.selectCurrentLocationInitially = true
            
            locationPicker.completion = { self.location = $0 }
        }
    }
    
    @IBAction func clearBtnAction(_ sender: Any) {
        productNameTF.text = ""
        categoryTF.text =  ""
        locationTF.text = ""
        priceTF.text = ""
        descriptionTF.text = ""
        noteTF.text = ""
    }
    
    @IBAction func addBtnAction(_ sender: Any) {
        ProgressHUD.present(view: self.view, mview: self)
        if productNameTF.text?.isEmpty == false && categoryTF.text?.isEmpty == false && subCategoryTF.text?.isEmpty == false && locationTF.text?.isEmpty == false && priceTF.text?.isEmpty == false {
            
            let fb = Firestore.firestore()
            let ref = fb.collection("Products").document()
            let uid =  ref.documentID
            
            let saveImageVM = FirebaseViewModel()
            
            saveImageVM.SaveImage(Title: productNameTF.text!, selectedImage: self.selectedImage) { uploadImageUrl, Status, errorMsg in
                ProgressHUD.dismiss()
                if Status {
                    let dict = [
                        "id" : uid,
                        "name": self.productNameTF.text!,
                        "category":self.subCategoryTF.text!,
                        "createdBy":currentUserProfile?.name ?? "",
                        "createdID":userUUID,
                        "price": self.priceTF.text!,
                        "image":uploadImageUrl!,
                        "lat":self.selectedLat,
                        "long":self.selectLong,
                        "description": (self.descriptionTF.text ?? ""),
                        "note": (self.noteTF.text ?? ""),
                        "available": true] as [String : Any]
                    
                    print(dict)
                    ref.setData(dict)
                    
                    let newValue = Product(id_value: uid, name_value: self.productNameTF.text!, category_value: self.subCategoryTF.text!, created: currentUserProfile?.name ?? "", createId: userUUID, price_value: self.priceTF.text!, image_value: uploadImageUrl!, lat: self.selectedLat, long: self.selectLong, description_value: (self.descriptionTF.text ?? ""), note_value: (self.noteTF.text ?? ""), available: true)
                    
                    self.addProtocol.updateTable(item: newValue)
                    self.navigationController?.popViewController(animated: true)
                } else{
                    print("\(errorMsg)")
                }
            }
        }
    }
}




//MARK:  EXTENSION
extension AddProductVC: UITextFieldDelegate {
    func textFieldDidBeginEditing(_ textField: UITextField) {
        if textField == categoryTF {
            categoryTF.inputView = pickerView
        }else if textField == subCategoryTF {
            if subCategoryList.count > 0 {subCategoryTF.inputView = subPickerView}else {
                AlertController.present("Please Select Category First")
            }
            
        }
        else {
            textField.inputView = nil
        }
    }
}

//MARK: - UIPickerViewDelegate UIPickerViewDataSource
extension AddProductVC: UIPickerViewDelegate, UIPickerViewDataSource {
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if pickerView == self.pickerView{return  categoryList.count}else {return subCategoryList.count}
    }
    
    func pickerView( _ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if pickerView == self.pickerView{return categoryList[row].name}else {return subCategoryList[row].name}
        
    }
    
    func pickerView( _ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        if pickerView == self.pickerView{
            categoryTF.text = categoryList[row].name
            subCategoryList = categoryList[row].subCategory
            categoryTF.resignFirstResponder()
            subCategoryTF.text = ""
        }else {
            subCategoryTF.text = subCategoryList[row].name
            subCategoryTF.resignFirstResponder()
        }
 
    }
}
//MARK: -
extension AddProductVC: UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        picker.dismiss(animated: true, completion: nil)
        guard let originalImage = info[UIImagePickerController.InfoKey.originalImage] as? UIImage else {
            return
        }
        //for image rotation
        let image =  originalImage.upOrientationImage()
        productImage.image = image
        self.selectedImage = image!
    }
}




extension AddProductVC: CLLocationManagerDelegate {
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        let locValue:CLLocationCoordinate2D = manager.location!.coordinate
        print("locations = \(locValue.latitude) \(locValue.longitude)")
        locationManager.stopUpdatingHeading()
        
        self.lat = locValue.latitude
        self.long = locValue.longitude
        
        print(self.lat)
        print(self.long)
    }
    
}

