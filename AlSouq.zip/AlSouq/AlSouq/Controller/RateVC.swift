//
//  CRateVC.swift
//  Alsouq
//
//  Created by Lola M on 1/15/22.
//

import UIKit
import HCSStarRatingView
import Firebase


class RateVC: UIViewController {
    
    @IBOutlet weak var productTitle: UILabel!
    @IBOutlet weak var review: UITextView!
    @IBOutlet weak var rate: HCSStarRatingView!
    
    var product : Product_Distance!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.isNavigationBarHidden = true
    }
    
    @IBAction func backBtnAction(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func submitBtnAction(_ sender: Any) {
        print(rate.value)
        let fb = Firestore.firestore()
        let ref = fb.collection("Review").document()
        let dict  = [
            "id":ref.documentID,
            "productID": product.id,
            "sellerID":product.createdID,
            "buyerID":userUUID,
            "buyerName":(currentUserProfile?.name ?? "unknown"),
            "rate":rate.value,
            "comment":review.text!,
            "status":false] as [String:Any]
        
        ref.setData(dict)
        self.navigationController?.popViewController(animated: true)
    }
}
