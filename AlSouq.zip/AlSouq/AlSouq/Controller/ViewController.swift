//
//  ViewController.swift
//  Alsouq
//
//  Created by Lola M on 1/15/22.
//

import UIKit
import CountryPicker
import Firebase

var tempPhoneNumber = ""
class ViewController: UIViewController {
    
    // MARK: - IBOutlet
    @IBOutlet weak var countryCodeButton: UIButton!
    @IBOutlet weak var countryImageView: UIImageView!
    @IBOutlet weak var phoneNumber: UITextField!
    @IBOutlet weak var pickCountryButton: UIButton!
    
    // MARK: - Func
    override func viewDidLoad() {
        super.viewDidLoad()
        //        self.addAccessibilityLabel()
        if #available(iOS 13.0, *) {
            //self.addSystemColor()
        }
        guard let country = CountryManager.shared.currentCountry else {
            self.countryCodeButton.setTitle("Pick Country", for: .normal)
            self.countryImageView.isHidden = true
            return
        }
        
        countryCodeButton.setTitle(country.dialingCode, for: .normal)
        countryImageView.image = country.flag
        countryCodeButton.clipsToBounds = true
        countryCodeButton.accessibilityLabel = Accessibility.selectCountryPicker
    }
    
    
    // MARK: - IBAction Methods
    @IBAction func filterByCountryCode(_ sender: UISwitch) {
        if sender.isOn {
            CountryManager.shared.addFilter(.countryCode)
        } else {
            CountryManager.shared.removeFilter(.countryCode)
        }
    }
    
    @IBAction func continueBtn() {
        
        let phoneNumber = "\(countryCodeButton.titleLabel?.text ?? "+1")\(phoneNumber.text ?? "00000")"
        
        print(phoneNumber)
        
        tempPhoneNumber = phoneNumber
        ProgressHUD.present(view: self.view, mview: self)
        PhoneAuthProvider.provider()
            .verifyPhoneNumber(phoneNumber, uiDelegate: nil) { verificationID, error in
                ProgressHUD.dismiss()
                if let error = error {
                    let alertVC = UIAlertController(title: "Error!", message: "\(error.localizedDescription)", preferredStyle: .alert)
                    let alertBtn = UIAlertAction(title: "OK", style: .default, handler: nil)
                    alertVC.addAction(alertBtn)
                    self.present(alertVC, animated: true, completion: nil)
                    return
                }
                // Sign in using the verificationID and the code sent to the user
                // ...
                guard let verifyID = verificationID else { return }
                UserDefaults.standard.set(verifyID, forKey: "authID")
                self.performSegue(withIdentifier: "verify", sender: nil)
            }
    }
    
    
    @IBAction func filterByDialCode(_ sender: UISwitch) {
        if sender.isOn {
            CountryManager.shared.addFilter(.countryDialCode)
        } else {
            CountryManager.shared.removeFilter(.countryDialCode)
        }
    }
    
    
    @IBAction func pickCountryAction(_ sender: UIButton) {
        presentCountryPickerScene(withSelectionControlEnabled: true)
    }
}


// MARK:  - Private Methods
private extension ViewController {
    func presentCountryPickerScene(withSelectionControlEnabled selectionControlEnabled: Bool = true) {
        switch selectionControlEnabled {
        case true:
            // Present country picker with `Section Control` enabled
            let countryController = CountryPickerWithSectionViewController.presentController(on: self) { [weak self] (country: Country) in
                
                guard let self = self else { return }
                
                self.countryImageView.isHidden = false
                self.countryImageView.image = country.flag
                self.countryCodeButton.setTitle(country.dialingCode, for: .normal)
            }
            
            countryController.flagStyle = .circular
            countryController.isCountryFlagHidden = false
            countryController.isCountryDialHidden = false
            countryController.favoriteCountriesLocaleIdentifiers = ["IN", "US"]
        case false:
            // Present country picker without `Section Control` enabled
            let countryController = CountryPickerController.presentController(on: self) { [weak self] (country: Country) in
                
                guard let self = self else { return }
                self.countryImageView.isHidden = false
                self.countryImageView.image = country.flag
                self.countryCodeButton.setTitle(country.dialingCode, for: .normal)
            }
            countryController.flagStyle = .corner
            countryController.isCountryFlagHidden = false
            countryController.isCountryDialHidden = false
            countryController.favoriteCountriesLocaleIdentifiers = ["IN", "US"]
        }
    }
}
