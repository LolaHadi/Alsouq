//
//  OrderVC.swift
//  Alsouq
//
//  Created by Lola M on 1/15/22.
//

import UIKit
import SDWebImage
import Firebase


protocol addProdProtocol {
    func updateTable(item: Product)
}

class OrderVC: UIViewController, addProdProtocol {
    
    func updateTable(item: Product) {
        productList.append(item)
        tableView.reloadData()
    }
    
    
    @IBOutlet var tableView: UITableView!
    @IBOutlet weak var profileImage: Custom_ImageView!
    @IBOutlet weak var rating: UILabel!
    @IBOutlet weak var NameTF: UILabel!
    var productList = [Product]()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.delegate = self
        tableView.dataSource = self
        tableView.reloadData()
        
        let url = URL(string:currentUserProfile?.image ?? "")
        profileImage.sd_setImage(with: url, placeholderImage: UIImage(systemName: "person.circle"), options: .progressiveLoad)
        
        NameTF.text = currentUserProfile?.name ?? "---"
        rating.text = "\(currentUserProfile?.rate ?? 0)"
        productList.removeAll()
        getSeller()
    }
    
    
    func viewWillAppear() {
        super.viewWillAppear(true)
        productList.removeAll()
        getSeller()
    }
    
    
    func getPurchase() {
        let vm = FirebaseViewModel()
        ProgressHUD.present(view: self.view, mview: self)
        vm.getPurchase(completion: { products, Status, errorMsg in
            ProgressHUD.dismiss()
            if Status {
                self.productList = products
                self.tableView.reloadData()
            } else {
                let alertVC = UIAlertController(title: "Error!", message: "\(errorMsg!)", preferredStyle: .alert)
                let alertBtn = UIAlertAction(title: "OK", style: .default, handler: nil)
                alertVC.addAction(alertBtn)
                self.present(alertVC, animated: true, completion: nil)
            }
        })
    }
    
    
    func getSeller() {
        let vm = FirebaseViewModel()
        ProgressHUD.present(view: self.view, mview: self)
        vm.getSeller(completion: { products, Status, errorMsg in
            ProgressHUD.dismiss()
            if Status {
                self.productList = products
                self.productList.count == 0 ? self.tableView.setEmptyView( message: "Please add new products.") : self.tableView.restore()
                self.tableView.reloadData()
            } else {
                let alertVC = UIAlertController(title: "Error!", message: "\(errorMsg!)", preferredStyle: .alert)
                let alertBtn = UIAlertAction(title: "OK", style: .default, handler: nil)
                alertVC.addAction(alertBtn)
                self.present(alertVC, animated: true, completion: nil)
            }
        })
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "NEW" {
            let dest = segue.destination as!AddProductVC
            dest.addProtocol = self
        }
    }
    
    
    @objc func changeStatus(_ button: UIButton) {
        let fs =  Firestore.firestore()
        let status = button.titleLabel?.text
        
        if status == "Available" {
            button.setTitle("Out of Stock", for: .normal)
            button.tintColor = UIColor.red
            
            fs.collection("Products").document(productList[button.tag].id).updateData(["available": false])
        } else {
            button.setTitle("Available", for: .normal)
            button.tintColor = UIColor.blue
            fs.collection("Products").document(productList[button.tag].id).updateData(["available": true])
        }
    }
}


extension OrderVC: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return productList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Profile", for: indexPath) as! ProfileTableViewCell
        
        cell.title.text = productList[indexPath.row].name
        let url = URL(string:productList[indexPath.row].image)
        cell.foodImage.sd_setImage(with: url, placeholderImage: nil, options: .progressiveLoad)
        cell.price.text = "SR \(productList[indexPath.row].price)"
        
        if productList[indexPath.row].available ?? true{
            cell.statusBtn.setTitle("Available", for: .normal)
            cell.statusBtn.tintColor = UIColor.blue
        } else {
            cell.statusBtn.setTitle("Out of Stock", for: .normal)
            cell.statusBtn.tintColor = UIColor.red
        }
        
        cell.statusBtn.tag = indexPath.row
        cell.statusBtn.addTarget(self, action: #selector(changeStatus), for: .touchUpInside)
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 160
        
    }
}
