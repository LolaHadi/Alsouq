//
//  ConversationVC.swift
//  Alsouq
//
//  Created by Lola M on 1/15/22.
//

import UIKit
import MessageKit
import InputBarAccessoryView
import CodableFirebase
import Firebase

class ConversationVC: MessagesViewController {
    
    
    //MARK:  VARIABLES
    var currentUser = Sender(senderId: "", displayName: "")
    var otherUser = Sender(senderId: "", displayName: "")
    var messages = [MessageType]()
    var  channelName = ""
    
    
    //MARK:  FUNCTIONS
    func insertMessage(_ message: Message) {
        messages.append(message)
        // Reload last section to update header/footer labels and insert a new one
        messagesCollectionView.performBatchUpdates({
            messagesCollectionView.insertSections([messages.count - 1])
            if messages.count >= 2 {
                messagesCollectionView.reloadSections([messages.count - 2])
            }
        }, completion: { [weak self] _ in
            //                if self?.isLastSectionVisible() == true {
            //                    self?.messagesCollectionView.scrollToLastItem(animated: true)
            //                }
        })
    }
    
    
    //MARK:  VIEW FUNCTIONS
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.isNavigationBarHidden = false
        print(currentUser)
        print(otherUser)
        print(channelName)
        
        messagesCollectionView.messagesDataSource = self
        messagesCollectionView.messagesLayoutDelegate = self
        messagesCollectionView.messagesDisplayDelegate = self
        scrollsToLastItemOnKeyboardBeginsEditing = true // default false
        maintainPositionOnKeyboardFrameChanged = true // default false
        showMessageTimestampOnSwipeLeft = true // default false
        
        messageInputBar.delegate = self
        self.getConversation()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        var arr = [currentUser.senderId, otherUser.senderId]
        arr.sort()
        channelName = arr.joined(separator:"_")
    }
    
    func getConversation() {
        var arr = [currentUser.senderId, otherUser.senderId]
        arr.sort()
        channelName = arr.joined(separator:"_")
        
        let vm = FirebaseViewModel()
        vm.GetConversation(channel: channelName) { chat, Status, errorMsg in
            
            if Status {
                self.messages.removeAll()
                chat.forEach { chatData in
                    let temp = Message(sender: Sender(senderId: chatData.senderId, displayName: chatData.displayName), messageId: chatData.messageId, sentDate: chatData.sentDate.dateValue(), kind: .text(chatData.message))
                    
                    self.messages.append(temp)
                }
                self.messagesCollectionView.reloadData()
            }
        }
    }
}



//MARK:  EXTENSION
extension ConversationVC: MessagesLayoutDelegate, MessagesDataSource, MessagesDisplayDelegate {
    
    func currentSender() -> SenderType {
        return currentUser
    }
    
    func messageForItem(at indexPath: IndexPath, in messagesCollectionView: MessagesCollectionView) -> MessageType {
        messages[indexPath.section]
    }
    
    func numberOfSections(in messagesCollectionView: MessagesCollectionView) -> Int {
        return messages.count
    }
    
}



extension ConversationVC: InputBarAccessoryViewDelegate {
    
    func inputBar(_ inputBar: InputBarAccessoryView, didPressSendButtonWith text: String) {
        let newMsg = Message(sender: currentUser, messageId: UUID().uuidString, sentDate: Date(), kind: .text(text))
        let fs = Firestore.firestore()
        let mainDict = [
            "channelID":channelName,
            "users": ["\(currentUser.senderId)","\(otherUser.senderId)"]] as [String:Any]
        fs.collection("Chatroom").document(channelName).setData(mainDict)
        
        let ref = fs.collection("Chatroom").document(channelName).collection("Chats").document()
        let dic = [
            "id":ref.documentID,
            "channelID":channelName,
            "messageId": UUID().uuidString,
            "senderId": currentUser.senderId,
            "displayName": currentUser.displayName,
            "sentDate": Date(),
            "kind": "text",
            "message": text,
            "users": ["\(currentUser.senderId)","\(otherUser.senderId)"]
        ] as [String:Any]
        
        ref.setData(dic)
        
        messages.append(newMsg)
        inputBar.inputTextView.text = ""
        messagesCollectionView.reloadData()
        messagesCollectionView.scrollToLastItem(animated: true)
    }
}
