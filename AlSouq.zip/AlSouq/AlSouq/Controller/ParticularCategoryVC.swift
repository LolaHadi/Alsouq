//
//  ParticularCategoryVC.swift
//  Alsouq
//
//  Created by Lola M on 1/15/22.
//

import UIKit
import SDWebImage
import Firebase
import CoreLocation

class ParticularCategoryVC:UIViewController {
    //MARK: - IB Outlet
    @IBOutlet var tableView: UITableView!
    @IBOutlet weak var categoriesCollection: UICollectionView!
    @IBOutlet weak var subCategoriesCollection: UICollectionView!
    @IBOutlet weak var searchTF : UITextField!
    @IBOutlet weak var rangeView : UIView!
    @IBOutlet weak var rangeTF : UITextField!
    
    //MARK: - Local variables
    var categoryIndex = 0
    var categoryIds = [Int]()
    var subCategoryIds = [Int]()
    var CategoryList = [Category]()
    var subCategoryList = [SubCategory]()
    var locationManager = CLLocationManager()
    var categoryTitle = ""
    var productList = [Product]()
    var finalList = [Product_Distance]()
    var displayList = [Product_Distance]()
    var selectedproduct = -1
    var lat  = 0.0
    var  long = 0.0
    var range = 12345.000
    
    //MARK: - View Life Cyle
    override func viewDidLoad() {
        super.viewDidLoad()
        rangeView.isHidden = true
        self.navigationController?.isNavigationBarHidden = true
        setupUI()
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        let indexPath = IndexPath(item: categoryIndex, section: 0)
        self.categoriesCollection.scrollToItem(at: indexPath, at: [.centeredVertically, .centeredHorizontally], animated: true)
    }
    
    func setupUI(){
       
        setupLocation()
        searchTF.delegate = self
        addCategoryToList()
    }
    
    func setupLocation(){
        locationManager.delegate = self;
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.requestAlwaysAuthorization()
        locationManager.startUpdatingLocation()
    }
    
    func addCategoryToList(){
        CategoryList  = Utilities.getCategories()
        
        categoryIds.append(categoryIndex)
        subCategoryIds.append(0)
        categoryTitle = CategoryList[categoryIndex].subCategory[0].name
        subCategoryList = CategoryList[categoryIndex].subCategory
        categoriesCollection.reloadData()
        subCategoriesCollection.reloadData()
        
        if categoryTitle == "All Categories" {self.getAllProduct()} else {self.getProduct()}
    }
    
    func getAllProduct() {
        
        let vm = FirebaseViewModel()
        ProgressHUD.present(view: self.view, mview: self)
        vm.AllProduct(completion: { products, Status, errorMsg in
            ProgressHUD.dismiss()
            if Status {
                self.productList = products
                self.nearestAlgo()
            } else {
                let alertVC = UIAlertController(title: "Error!", message: "\(errorMsg!)", preferredStyle: .alert)
                let alertBtn = UIAlertAction(title: "OK", style: .default, handler: nil)
                alertVC.addAction(alertBtn)
                self.present(alertVC, animated: true, completion: nil)
            }
        })
    }
    
    
    
    func getProduct() {
        
        let vm = FirebaseViewModel()
        ProgressHUD.present(view: self.view, mview: self)
        vm.ProductByCategory(title: categoryTitle,completion: { products, Status, errorMsg in
            ProgressHUD.dismiss()
            if Status {
                self.productList = products
                self.nearestAlgo()
            } else {
                let alertVC = UIAlertController(title: "Error!", message: "\(errorMsg!)", preferredStyle: .alert)
                let alertBtn = UIAlertAction(title: "OK", style: .default, handler: nil)
                alertVC.addAction(alertBtn)
                self.present(alertVC, animated: true, completion: nil)
            }
        })
    }
    
    
    @IBAction func geoBtnAction(_ button: UIButton) {
        UIView.animate(withDuration: 2) {
            self.rangeView.isHidden = false
        }
    }
    
    
    @IBAction func enterBtnAction(_ button: UIButton) {
        UIView.animate(withDuration: 2) {
            
            print(self.rangeTF.text)
            self.range = (self.rangeTF.text as! NSString).doubleValue
            self.rangeView.isHidden = true
            if self.categoryTitle == "All Categories"{
                self.productList.removeAll()
                self.displayList.removeAll()
                self.finalList.removeAll()
                self.tableView.reloadData()
                self.getAllProduct()
            } else {
                
                self.productList.removeAll()
                self.displayList.removeAll()
                self.finalList.removeAll()
                self.tableView.reloadData()
                self.getProduct()
            }
        }
    }
    
    
    @objc func heartBtnAction(btn: UIButton) {
        
        //        print(btn.tag)
        let alertVC = UIAlertController(title: "Desire Action", message: "", preferredStyle: .actionSheet)
        let favBtn = UIAlertAction(title: "Add Favourite", style: .default) { action in
            let fb = Firestore.firestore()
            var temp =  (currentUserProfile?.fav)!
            temp.append(self.displayList[btn.tag].id)
            currentUserProfile?.fav = temp
            fb.collection("Users").document("\(userUUID)").updateData(["fav":temp])
            currentUserProfile?.fav?.append(self.displayList[btn.tag].id)
            //            btn.setImage(UIImage(systemName: "heart.fill"), for: .normal)
            
            if self.categoryTitle == "All Categories" {
                self.getAllProduct()
            } else {
                self.getProduct()
            }
        }
        
        
        let cancel = UIAlertAction(title: "Cancel", style: .cancel)
        alertVC.addAction(favBtn)
        alertVC.addAction(cancel)
        self.present(alertVC, animated: true)
    }
    
    
    @objc func chatBtnAction(btn: UIButton) {
        
        let chatVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "Chat") as! ConversationVC
        chatVC.currentUser = Sender(senderId: userUUID, displayName: (currentUserProfile?.name)!)
        chatVC.otherUser = Sender(senderId: productList[btn.tag].createdID, displayName: productList[btn.tag].createdBy)
        self.present(chatVC, animated: true)
    }
    
    
    func nearestAlgo() {
        var prod_dist = [Product_Distance]()
        
        productList.forEach { Item in
            let coordinate₀ = CLLocation(latitude: self.lat, longitude: self.long)
            let coordinate₁ = CLLocation(latitude: (Item.lat), longitude: (Item.long))
            let distanceInMeters = coordinate₀.distance(from: coordinate₁)
            
            print(distanceInMeters)
            
            prod_dist.append( Product_Distance(id: Item.id, name: Item.name, category: Item.category, createdBy: Item.createdBy, createdID: Item.createdID, price: Item.price, image: Item.image, lat: Item.lat, long: Item.long, distance: distanceInMeters, description: Item.description, note: Item.note))
        }
        
        print(prod_dist.count)
        print(prod_dist.first?.name)
        print(prod_dist.last?.name)
        displayList.removeAll()
        let sortedValue = prod_dist.sorted(by: {$0.distance < $1.distance})
        sortedValue.forEach { val in
            print(val.distance/1000)
            if (val.distance/1000) < range {
                self.displayList.append(val)
            }
        }
        
        self.finalList = self.displayList
        self.displayList.count == 0 ? self.tableView.setEmptyView() : self.tableView.restore()
        tableView.reloadData()
        print(prod_dist.first?.name)
    }
    
    
    @IBAction func backBtnAction(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
}



//MARK: - UITableViewDelegate , UITableViewDataSource
extension ParticularCategoryVC: UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return displayList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "P_Category", for: indexPath) as! ProfileTableViewCell
        cell.title.text = displayList[indexPath.row].name
        let url = URL(string:displayList[indexPath.row].image)
        cell.foodImage.sd_setImage(with: url, placeholderImage: nil, options: .progressiveLoad)
        cell.price.text = "SR \(displayList[indexPath.row].price)"
        
        if let arr = (currentUserProfile?.fav) {
            let checkFav = arr.contains("\(displayList[indexPath.row].id)")
            if checkFav {
                cell.heartBtn.setImage(UIImage(systemName: "heart.fill"), for: .normal)
            } else {
                cell.heartBtn.setImage(UIImage(systemName: "heart"), for: .normal)
                cell.heartBtn.tag = indexPath.row
                cell.heartBtn.addTarget(self, action:  #selector(heartBtnAction), for: .touchUpInside)
            }
        }
        
        cell.chatBtn.tag = indexPath.row
        cell.chatBtn.addTarget(self, action:  #selector(chatBtnAction), for: .touchUpInside)
        
        let myDouble = displayList[indexPath.row].distance / 1000
        let doubleStr = String(format: "%.2f", myDouble)
        cell.distance.text = "\(doubleStr) km"
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 120
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.selectedproduct = indexPath.row
        self.performSegue(withIdentifier: "Detail", sender: nil)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let dest = segue.destination as! DetailViewController
        dest.productDetail = displayList[self.selectedproduct]
    }
}

//Extension
//MARK: - UICollectionViewDelegate , UICollectionViewDataSource
extension ParticularCategoryVC: UICollectionViewDelegate,UICollectionViewDataSource{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if collectionView == categoriesCollection {
            return CategoryList.count
        }else {
            return subCategoryList.count
        }
        
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        // get a reference to our storyboard cell
        if collectionView == categoriesCollection {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "collection", for: indexPath as IndexPath) as! CategoryCollectionViewCell
            cell.title.text = CategoryList[indexPath.row].name
            cell.catergoryImage.image = UIImage(named: CategoryList[indexPath.row].name)
            if categoryIds.contains(indexPath.row) {
                cell.mainView.backgroundColor = UIColor.green
            }else {cell.mainView.backgroundColor = UIColor.white}
            return cell
        }else {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "collection", for: indexPath as IndexPath) as! SubCategoryCollectionViewCell
            cell.title.text = subCategoryList[indexPath.row].name
            cell.catergoryImage.image = UIImage(named: subCategoryList[indexPath.row].name)
            if subCategoryIds.contains(indexPath.row) {
                cell.mainView?.backgroundColor = UIColor.green
            }else {cell.mainView?.backgroundColor = UIColor.white}
            return cell
        }

        
    }
   func cc() {
        CategoryList  = Utilities.getCategories()
        
        categoryIds.append(categoryIndex)
        subCategoryIds.append(0)
        categoryTitle = CategoryList[categoryIndex].subCategory[0].name
        subCategoryList = CategoryList[categoryIndex].subCategory
        categoriesCollection.reloadData()
        subCategoriesCollection.reloadData()
        
        if categoryTitle == "All Categories" {self.getAllProduct()} else {self.getProduct()}
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
       
        if collectionView == categoriesCollection {
           let data = CategoryList[indexPath.row]
            subCategoryList = data.subCategory
            
            categoryIds.removeAll()
            categoryIds.append(indexPath.row)
            
            //changing subcategories
            subCategoryIds.removeAll()
            subCategoryIds.append(0)
            categoryTitle = data.subCategory[0].name
            self.getProduct()
            
            categoriesCollection.reloadData()
            subCategoriesCollection.reloadData()
            

        }else {
            
            categoryTitle = subCategoryList[indexPath.row].name
            subCategoryIds.removeAll()
            subCategoryIds.append(indexPath.row)
            subCategoriesCollection.reloadData()
    
            if categoryTitle == "All Categories" {
                self.getAllProduct()
            } else {
                self.getProduct()
            }
        }
       
        //productList.removeAll()

    }
}
//MARK: - UICollectionViewDelegateFlowLayout
extension ParticularCategoryVC: UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        if collectionView == categoriesCollection {
            return CGSize(width: 200, height: 150)
        }else {
            return CGSize(width: 90, height: 120)
        }
    }
}

//MARK: - CLLocationManagerDelegate
extension ParticularCategoryVC: CLLocationManagerDelegate {
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        let locValue:CLLocationCoordinate2D = manager.location!.coordinate
        print("locations = \(locValue.latitude) \(locValue.longitude)")
        locationManager.stopUpdatingHeading()
        
        self.lat = locValue.latitude
        self.long = locValue.longitude
        
        print(self.lat)
        print(self.long)
    }
}

//MARK: - UITextFieldDelegate
extension ParticularCategoryVC: UITextFieldDelegate{
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        let result  = finalList.filter({$0.name.contains(textField.text ?? "")})
        displayList = result
        tableView.reloadData()
        return true
    }
}

