//
//  VerifyVC.swift
//  Alsouq
//
//  Created by Lola M on 1/15/22.
//

import UIKit
import OTPFieldView
import Firebase

class VerifyVC: UIViewController, OTPFieldViewDelegate {
    
    @IBOutlet weak var otpTextFieldView: OTPFieldView!
    
    var otpCode = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupOtpView()
    }
    
    func setupOtpView() {
            self.otpTextFieldView.fieldsCount = 6
            self.otpTextFieldView.fieldBorderWidth = 2
            self.otpTextFieldView.defaultBorderColor = UIColor.black
            self.otpTextFieldView.filledBorderColor = UIColor.gray
            self.otpTextFieldView.cursorColor = UIColor.red
            self.otpTextFieldView.displayType = .roundedCorner
            self.otpTextFieldView.fieldSize = 40
            self.otpTextFieldView.separatorSpace = 8
            self.otpTextFieldView.shouldAllowIntermediateEditing = false
            self.otpTextFieldView.delegate = self
            self.otpTextFieldView.initializeUI()
        }
    
    @IBAction func verifyBtn() {
        let verificationID = UserDefaults.standard.string(forKey: "authID")
        let credential = PhoneAuthProvider.provider().credential(
            withVerificationID: verificationID!,
          verificationCode: otpCode
        )
        ProgressHUD.present(view: self.view, mview: self)
        Auth.auth().signIn(with: credential) { authResult, error in
            ProgressHUD.dismiss()
            if let error = error {
              let authError = error as NSError
//              if isMFAEnabled, authError.code == AuthErrorCode.secondFactorRequired.rawValue {
//                // The user is a multi-factor user. Second factor challenge is required.
//                let resolver = authError
//                  .userInfo[AuthErrorUserInfoMultiFactorResolverKey] as! MultiFactorResolver
//                var displayNameString = ""
//                for tmpFactorInfo in resolver.hints {
//                  displayNameString += tmpFactorInfo.displayName ?? ""
//                  displayNameString += " "
//                }
//                self.showTextInputPrompt(
//                  withMessage: "Select factor to sign in\n\(displayNameString)",
//                  completionBlock: { userPressedOK, displayName in
//                    var selectedHint: PhoneMultiFactorInfo?
//                    for tmpFactorInfo in resolver.hints {
//                      if displayName == tmpFactorInfo.displayName {
//                        selectedHint = tmpFactorInfo as? PhoneMultiFactorInfo
//                      }
//                    }
//                    PhoneAuthProvider.provider()
//                      .verifyPhoneNumber(with: selectedHint!, uiDelegate: nil,
//                                         multiFactorSession: resolver
//                                           .session) { verificationID, error in
//                        if error != nil {
//                          print(
//                            "Multi factor start sign in failed. Error: \(error.debugDescription)"
//                          )
//                        } else {
//                          self.showTextInputPrompt(
//                            withMessage: "Verification code for \(selectedHint?.displayName ?? "")",
//                            completionBlock: { userPressedOK, verificationCode in
//                              let credential: PhoneAuthCredential? = PhoneAuthProvider.provider()
//                                .credential(withVerificationID: verificationID!,
//                                            verificationCode: verificationCode!)
//                              let assertion: MultiFactorAssertion? = PhoneMultiFactorGenerator
//                                .assertion(with: credential!)
//                              resolver.resolveSignIn(with: assertion!) { authResult, error in
//                                if error != nil {
//                                  print(
//                                    "Multi factor finanlize sign in failed. Error: \(error.debugDescription)"
//                                  )
//                                } else {
//                                  self.navigationController?.popViewController(animated: true)
//                                }
//                              }
//                            }
//                          )
//                        }
//                      }
//                  }
//                )
//              }
//                else {
//                self.showMessagePrompt(error.localizedDescription)
                let alertVC = UIAlertController(title: "Error!", message: "\(error.localizedDescription)", preferredStyle: .alert)
                let alertBtn = UIAlertAction(title: "OK", style: .default, handler: nil)
                alertVC.addAction(alertBtn)
                self.present(alertVC, animated: true, completion: nil)
                
                //return
//              }
              return
            }
            // User is signed in
            else {
                let id = (authResult?.user.uid)!
                let fb = Firestore.firestore()
                fb.collection("Users").document("\(id)").setData([
                    "uid":id,
                     "image":"",
                     "name":"",
                     "number": tempPhoneNumber,
                     "rate":0,
                     "purchases":[],
                     "wish":[],
                     "fav":[]
                    ])
                
                UserDefaults.standard.set(true, forKey: "Auth")
                UserDefaults.standard.set(id, forKey: "uid")
                
                userUUID = id
                self.performSegue(withIdentifier: "dashboard", sender: nil)
            }
            // ...
        }
    }

}



//Extension
extension VerifyVC {
    
    func hasEnteredAllOTP(hasEnteredAll hasEntered: Bool) -> Bool {
        print("Has entered all OTP? \(hasEntered)")
        return false
    }
    
    func shouldBecomeFirstResponderForOTP(otpTextFieldIndex index: Int) -> Bool {
        return true
    }
    
    func enteredOTP(otp otpString: String) {
        print("OTPString: \(otpString)")
        self.otpCode = otpString
    }
}
