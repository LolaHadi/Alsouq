//
//  ProfileVC.swift
//  Alsouq
//
//  Created by Lola M on 1/15/22.
//

import UIKit
import SDWebImage
import Firebase

class ProfileVC: UIViewController {
    
    //MARK: - IBOutlets
    @IBOutlet weak var profileImage: Custom_ImageView!
    @IBOutlet weak var rating: UILabel!
    @IBOutlet weak var NameTF: UILabel!
    @IBOutlet var favTable: UITableView!
    @IBOutlet var reviewTable: UITableView!
    
    //Vars
    var productList = [Product]()
    var ReviewList = [Review]()
    var selectedReview = -1
    
    
    //MARK: -  View Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        favTable.delegate = self
        favTable.dataSource = self
        favTable.reloadData()
        // self.getFav()
        reviewTable.delegate = self
        reviewTable.dataSource = self
        reviewTable.reloadData()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.getProfile()
        self.getFav()
        // self.getRequest()
        self.reviewTable.isHidden = true
        self.favTable.isHidden = false
        let url = URL(string:currentUserProfile?.image ?? "")
        profileImage.sd_setImage(with: url, placeholderImage: UIImage(systemName: "person.circle"), options: .progressiveLoad)
        NameTF.text = currentUserProfile?.name ?? "---"
    }
    
    
    //MARK: - FireBase Methods
    func getProfile() {
        let vm = FirebaseViewModel()
        ProgressHUD.present(view: self.view, mview: self)
        vm.GetProfile(completion: { profile, Status, errorMsg in
            ProgressHUD.dismiss()
            if Status {
                currentUserProfile = profile
            } else {
                let alertVC = UIAlertController(title: "Error!", message: "\(errorMsg!)", preferredStyle: .alert)
                let alertBtn = UIAlertAction(title: "OK", style: .default, handler: nil)
                alertVC.addAction(alertBtn)
                self.present(alertVC, animated: true, completion: nil)
            }
        })
    }
    
    
  
    
    func getFav() {
        self.productList.removeAll()
        self.favTable.reloadData()
        let vm = FirebaseViewModel()
        ProgressHUD.present(view: self.view, mview: self)
        vm.getFav(completion: { products, Status, errorMsg in
            ProgressHUD.dismiss()
            if Status {
                self.productList = products
                self.productList.count == 0 ? self.favTable.setEmptyView( message: "No product found") : self.favTable.restore()
                self.favTable.isHidden  = false
                self.favTable.reloadData()
            } else {
                let alertVC = UIAlertController(title: "Error!", message: "\(errorMsg!)", preferredStyle: .alert)
                let alertBtn = UIAlertAction(title: "OK", style: .default, handler: nil)
                alertVC.addAction(alertBtn)
                self.present(alertVC, animated: true, completion: nil)          }
        })
    }
    
    func getReview() {
        self.ReviewList.removeAll()
        self.reviewTable.reloadData()
        let vm = FirebaseViewModel()
        
        vm.getReview(id: userUUID) { review, Status, errorMsg in
            if Status {
                self.ReviewList = review
                self.ReviewList.count == 0 ? self.reviewTable.setEmptyView( message: "No review found") : self.reviewTable.restore()
                self.reviewTable.reloadData()
            }else {
                let alertVC = UIAlertController(title: "Error!", message: "\(errorMsg!)", preferredStyle: .alert)
                let alertBtn = UIAlertAction(title: "OK", style: .default, handler: nil)
                alertVC.addAction(alertBtn)
                self.present(alertVC, animated: true, completion: nil)          }
        }
    }
    
    
    func getRequest() {
        self.ReviewList.removeAll()
        self.reviewTable.reloadData()
        let vm = FirebaseViewModel()
        ProgressHUD.present(view: self.view, mview: self)
        vm.getRequest(id: userUUID) { review, Status, errorMsg in
            ProgressHUD.dismiss()
            if Status {
                self.ReviewList = review
                self.ReviewList.count == 0 ? self.reviewTable.setEmptyView( message: "No review found") : self.reviewTable.restore()
                self.reviewTable.reloadData()
            }
        }
    }
    
    //MARK: - IB Action
    @objc func heartBtnAction(btn: UIButton) {
        
        let alertVC = UIAlertController(title: "Desire Action", message: "", preferredStyle: .actionSheet)
        let favBtn = UIAlertAction(title: "Remove Favourite", style: .default) { action in
            
            let fb = Firestore.firestore()
            let temp =  (currentUserProfile?.fav)!
            let index = temp.firstIndex(of: self.productList[btn.tag].id)
            currentUserProfile?.fav?.remove(at: index!)
            let new = currentUserProfile?.fav ?? []
            fb.collection("Users").document("\(userUUID)").updateData(["fav":new])
            currentUserProfile?.fav? = new
            self.getFav()
        }
        
        let cancel = UIAlertAction(title: "Cancel", style: .cancel)
        alertVC.addAction(favBtn)
        alertVC.addAction(cancel)
        self.present(alertVC, animated: true)
    }
    @IBAction func segmentAction(_ sender: Custom_Segment) {
        print(sender.selectedSegmentIndex)
        
        if sender.selectedSegmentIndex == 0 {
            productList.removeAll()
            getFav()
            reviewTable.isHidden = true
            favTable.isHidden = false
        } else if sender.selectedSegmentIndex == 1 {
            getReview()
            reviewTable.isHidden = false
            favTable.isHidden = true
        } else {
            productList.removeAll()
            getRequest()
            reviewTable.isHidden = false
            favTable.isHidden = true
        }
    }
    
    
    @IBAction func editBtnAction(_ sender: UIButton) {
        performSegue(withIdentifier: "edit", sender: nil)
    }
    
    
    @IBAction func segmentBtn(_ sender: Custom_Segment) {
        sender.selectedSegmentIndex
    }
    
}


//MARK: - UITableViewDelegate UITableViewDataSource
extension ProfileVC: UITableViewDelegate, UITableViewDataSource{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView == favTable {
            return productList.count
        }
        else if tableView == reviewTable {
            return ReviewList.count
        }
        return 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if tableView == favTable {
            let cell = tableView.dequeueReusableCell(withIdentifier: "Profile", for: indexPath) as! ProfileTableViewCell
            cell.title.text = productList[indexPath.row].name
            let url = URL(string:productList[indexPath.row].image)
            cell.foodImage.sd_setImage(with: url, placeholderImage: nil, options: .progressiveLoad)
            cell.price.text = "SR \(productList[indexPath.row].price)"
            cell.sellerName.text = productList[indexPath.row].createdBy
            cell.heartBtn.tag = indexPath.row
            cell.heartBtn.addTarget(self, action: #selector(heartBtnAction), for: .touchUpInside)
            return cell
        }
        
        else if tableView == reviewTable {
            let cell = tableView.dequeueReusableCell(withIdentifier: "Rate", for: indexPath) as! ReviewTableCell
            cell.name.text = ReviewList[indexPath.row].buyerName
            cell.reviewText.text = ReviewList[indexPath.row].comment
            cell.rateStat.value = ReviewList[indexPath.row].rate
            return cell
        }
        return UITableViewCell()
    }
    
    
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if tableView == reviewTable {
            let ref = ReviewList[indexPath.row]
            
            let alert = UIAlertController(title: "Action", message: "Would u like to accept this review", preferredStyle: .alert)
            
            alert.addAction(UIAlertAction(title: "YES", style: .default, handler: { action in
                let fb = Firestore.firestore()
                fb.collection("Review").document(ref.id).updateData(["status":true])
                fb.collection("Users").document(userUUID).updateData(["rate": ref.rate])
                
                currentUserProfile?.rate = ref.rate
                self.rating.text = "\(ref.rate)"
                self.getRequest()
            }))
            alert.addAction(UIAlertAction(title: "NO", style: .cancel))
            self.present(alert, animated: true)
        } else if tableView == favTable {
            //..
        }
    }
    
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if tableView == reviewTable {
            return 200
        } else {
            return 160
        }
    }
}
