//
//  CategoriesVC.swift
//  Alsouq
//
//  Created by Lola M on 1/15/22.
//

import UIKit
import Firebase
import CodableFirebase
import AVFAudio

class CategoriesVC: UIViewController {
    //MARK: - IB outlet
    @IBOutlet var tableView: UITableView!
    
    //MARK: - Local variables
    var categoryList = [Category]()
    var productList = [Product]()
    var selectedIndex = -1
    
    //MARK: - View Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        categoryList = Utilities.getCategories()
        tableView.delegate = self
        tableView.dataSource = self
        tableView.reloadData()
        self.tabBarController?.tabBar.isHidden = false
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.tabBarController?.tabBar.isHidden = false
        self.getProfile()
    }
    
    //MARK:  -  FireBase Methods
    func getProfile() {
        let vm = FirebaseViewModel()
        
        vm.GetProfile(completion: { profile, Status, errorMsg in
            if Status {
                currentUserProfile = profile
            } else {
                let alertVC = UIAlertController(title: "Error!", message: "\(errorMsg!)", preferredStyle: .alert)
                let alertBtn = UIAlertAction(title: "OK", style: .default, handler: nil)
                alertVC.addAction(alertBtn)
                self.present(alertVC, animated: true, completion: nil)
            }
        })
    }
}

//MARK: - UITableViewDelegate
extension CategoriesVC: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return categoryList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Category", for: indexPath) as! CategoryTableViewCell
        cell.title.text = categoryList[indexPath.row].name
        cell.catergoryImage.image = UIImage(named: categoryList[indexPath.row].name)
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 80
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.selectedIndex = indexPath.row
        performSegue(withIdentifier: "ParticularCategoryVC", sender: nil)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let dest  = segue.destination as! ParticularCategoryVC
        // dest.categoryTitle = categories[self.selectedIndex]
        dest.categoryIndex = selectedIndex
    }
}
