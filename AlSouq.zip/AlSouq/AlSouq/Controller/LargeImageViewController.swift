//
//  LargeImageViewController.swift
//  Alsouq
//
//  Created by Lola M on 1/15/22.
//

import UIKit
import SDWebImage

class LargeImageViewController: UIViewController, UIScrollViewDelegate {

    @IBOutlet weak var scroll: UIScrollView!
    @IBOutlet weak var sellerTitle: UILabel!
    @IBOutlet weak var productLargeImage: UIImageView!
    
    var detail : Product_Distance!
    var size = 200
    
    override func viewDidLoad() {
        super.viewDidLoad()
        sellerTitle.text = detail.name
        let url2 = URL(string:(self.detail.image))
        self.productLargeImage.sd_setImage(with: url2, placeholderImage: nil, options: .progressiveLoad)
        self.scroll.minimumZoomScale = 1
        self.scroll.maximumZoomScale = 6
    }
    
    func viewForZooming(in scrollView: UIScrollView) -> UIView? {
        return self.productLargeImage
    }
    
    @IBAction func backBtnAction(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }

}
