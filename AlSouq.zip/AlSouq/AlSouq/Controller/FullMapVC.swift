//
//  CFullMapVC.swift
//  Alsouq
//
//  Created by Lola M on 1/15/22.
//

import UIKit
import MapKit
import CoreLocation

class FullMapVC: UIViewController {
    
    @IBOutlet weak var mapViewv : MKMapView!
    
    var dest : CLLocationCoordinate2D!
    var locationManager = CLLocationManager()
    var lat  = 0.0
    var  long = 0.0
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        locationManager.delegate = self;
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.requestAlwaysAuthorization()
        locationManager.requestWhenInUseAuthorization()
        locationManager.startUpdatingLocation()
        mapViewv.delegate = self
        
        let annotations = MKPointAnnotation()
        annotations.coordinate = CLLocationCoordinate2D(latitude: self.dest.latitude, longitude: self.dest.longitude)
        let spanRegion = MKCoordinateSpan(latitudeDelta: 0.0025, longitudeDelta: 0.0025)
        let mapRegion = MKCoordinateRegion(center: annotations.coordinate, span: spanRegion)
        self.mapViewv.addAnnotation(annotations)
        self.mapViewv.setRegion(mapRegion, animated: true)
        self.mapThis()
    }
    
    
    @IBAction func backBtnAction(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    func mapThis() {
        
        let scrCoordinate = (locationManager.location?.coordinate)!
        let scrPlaceMark = MKPlacemark(coordinate: scrCoordinate)
        let destPlaceMark = MKPlacemark(coordinate: dest)
        let scrItem = MKMapItem(placemark: scrPlaceMark)
        let destItem = MKMapItem(placemark: destPlaceMark)
        
        let destRequest = MKDirections.Request()
        destRequest.source = scrItem
        destRequest.destination = destItem
        destRequest.transportType = .automobile
        destRequest.requestsAlternateRoutes = true
        
        let direction = MKDirections(request: destRequest)
        direction.calculate { resp, err in
            guard let responce = resp else {
                print("ERooooooooR :\(err?.localizedDescription)")
                
                let alertView = UIAlertController(title: "Map Kit Error", message: "\((err?.localizedDescription)!)", preferredStyle: .alert)
                alertView.addAction(UIAlertAction(title: "Dismiss", style: .cancel))
                self.present(alertView, animated: true, completion: nil)
                return}
            
            let route = responce.routes[0]
            self.mapViewv.addOverlay(route.polyline)
            self.mapViewv.setVisibleMapRect(route.polyline.boundingMapRect, animated: true)
        }
    }
}


extension FullMapVC: CLLocationManagerDelegate, MKMapViewDelegate {
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        let locValue:CLLocationCoordinate2D = manager.location!.coordinate
        print("locations = \(locValue.latitude) \(locValue.longitude)")
        locationManager.stopUpdatingHeading()
        
        self.lat = locValue.latitude
        self.long = locValue.longitude
        
        print(self.lat)
        print(self.long)
    }
    
    func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
        let render = MKPolygonRenderer(overlay: overlay as! MKPolygon)
        render.strokeColor = .blue
        return render
    }
}
