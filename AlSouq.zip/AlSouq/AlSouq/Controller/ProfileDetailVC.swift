//
//  ProfileDetailVC.swift
//  Alsouq
//
//  Created by Lola M on 1/15/22.
//

import UIKit

class ProfileDetailVC: UIViewController {
    
    @IBOutlet weak var dpImage: UIImageView!
    @IBOutlet var productTable: UITableView!
    @IBOutlet weak var NameTF: UITextField!
    @IBOutlet weak var numberTF: UITextField!
    
    var userid = ""
    var productList = [Product]()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        productTable.delegate = self
        productTable.dataSource = self
        productTable.reloadData()
        self.getUserInfo()
        self.userProduct()
    }
    
    
    func getUserInfo() {
        let vm = FirebaseViewModel()
        vm.getUserProfile(id: userid) { [self] profile, Status, errorMsg in
            if Status {
                NameTF.text = profile?.name
                numberTF.text = profile?.number
                let url = URL(string:(profile!.image)!)
                self.dpImage.sd_setImage(with: url, placeholderImage: nil, options: .progressiveLoad)
            }
        }
    }
    
    
    func userProduct() {
        let vm = FirebaseViewModel()
        vm.UserProduct(id: userid) { [self] products, Status, errorMsg in
            if Status{
                productList = products
                productTable.reloadData()
            }
        }
    }
    
    
    @IBAction func backBtnAction(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
}



//Extension
extension ProfileDetailVC: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return productList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "P_Category", for: indexPath) as! ProfileTableViewCell
        cell.title.text = productList[indexPath.row].name
        let url = URL(string:productList[indexPath.row].image)
        cell.foodImage.sd_setImage(with: url, placeholderImage: nil, options: .progressiveLoad)
        cell.price.text = "SR \(productList[indexPath.row].price)"
        //            cell.sellerName.text = productList[indexPath.row].createdBy
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 160
    }
}
