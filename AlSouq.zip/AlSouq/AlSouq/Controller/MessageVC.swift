//
//  MessageVC.swift
//  Alsouq
//
//  Created by Lola M on 1/15/22.
//

import UIKit
import Firebase
import CodableFirebase
import SDWebImage


struct Messages {
    var recepitant  : Profile
    var channeliD : String
}


class MessageVC: UIViewController {
    
    
    //MARK: OUTLETS
    @IBOutlet weak var messagetable: UITableView!
    
    
    //MARK:  VARIABLES
    var otherList = [Messages]()
    var roomlist = [ChatRoom]()
    
    
    //MARK:  VIEW FUNCTIONS
    override func viewDidLoad() {
        super.viewDidLoad()
        messagetable.delegate = self
        messagetable.dataSource = self
        messagetable.reloadData()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        getList()
    }
    
    
    func getList() {
        self.otherList.removeAll()
        let vm = FirebaseViewModel()
        var result: Messages!
        ProgressHUD.present(view: self.view, mview: self)
        vm.GetChatRoom { chat, Status, errorMsg in
            ProgressHUD.dismiss()
            if Status {
                self.roomlist = chat
                self.roomlist.forEach { value in
                    value.users.forEach { usr in
                        if usr != userUUID {
                            vm.getUserProfile(id: usr) { profile, Status, errorMsg in
                                
                                if Status {
                                    let info = profile
                                    
                                    result = Messages(recepitant: info!, channeliD: value.channelID)
                                    
                                    self.otherList.append(result)
                                    self.otherList.count == 0 ? self.messagetable.setEmptyView( message: "No chat found") : self.messagetable.restore()
                                    self.messagetable.reloadData()
                                }
                            }
                        }
                    }
                    //                    self.otherList.append(value)
                    //                    self.messagetable.reloadData()
                }
                self.messagetable.reloadData()
            }
        }
    }
    //    {
    //        let vm = FirebaseViewModel()
    //        var result: Messages!
    //        guard let channelList = currentUserProfile?.channel else {return}
    //
    //        channelList.forEach { channelID in
    //
    //            let temp = channelID.split(separator: "_")
    //            let c = temp.map{String($0)}
    //           let index = c.firstIndex(of: userUUID)
    //
    //            if index == 0 {
    //
    ////                let value = Messages(recepitant: c[1], channel: channelID)
    //                vm.getUserProfile(id: c[1]) { profile, Status, errorMsg in
    //                    if Status{
    //
    //                        let info = profile
    //
    //                        let last = self.getLastMessage(channel: channelID)
    //
    //                        result = Messages(recepitant: info!, channelMessage: last, channeliD: channelID)
    //
    //                        self.otherList.append(result)
    //                        self.messagetable.reloadData()
    //
    //                        }
    //
    //                    }
    //                }
    //
    //
    //            else{
    //
    //                //                let value = Messages(recepitant: c[1], channel: channelID)
    //                                vm.getUserProfile(id: c[0]) { profile, Status, errorMsg in
    //                                    if Status{
    //
    //                                        let info = profile
    //
    //                                        let last = self.getLastMessage(channel: channelID)
    //
    //                                        result = Messages(recepitant: info!, channelMessage: last, channeliD: channelID)
    //
    //                                        self.otherList.append(result)
    //                                        self.messagetable.reloadData()
    //
    //                                        }
    //
    //                                    }
    //                                }
    //
    //
    //        }
    //    }
    
    
    func getLastMessage(channel:String) -> String {
        var msg  = ""
        Database.database().reference().child("Chatroom").child(channel).observeSingleEvent(of: .value) { snap in
            guard let value  = snap.value as? [String:Any]
            else{return}
            msg = value["message"] as? String ?? ""
        }
        return msg
    }
    
}




//MARK:  EXTENSION
extension MessageVC: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return otherList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Messages", for: indexPath) as! ChannelTableViewCell
        cell.sellerName.text = otherList[indexPath.row].recepitant.name
        let url = URL(string:otherList[indexPath.row].recepitant.image ?? "")
        cell.userDP.sd_setImage(with: url, placeholderImage: UIImage(systemName: "person.circle"), options: .progressiveLoad)
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 112
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        let vc = ConversationVC()
        vc.title = "Chat"
        vc.currentUser = Sender(senderId: "\(userUUID)", displayName: (currentUserProfile?.name)!)
        
        vc.otherUser = Sender(senderId: "\((otherList[indexPath.row].recepitant.uid))", displayName: "\((otherList[indexPath.row].recepitant.name)!)")
        vc.channelName = otherList[indexPath.row].channeliD
        navigationController?.pushViewController(vc, animated: true)
    }
}
