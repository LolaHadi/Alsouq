//
//  DetailViewController.swift
//  Alsouq
//
//  Created by Lola M on 1/15/22.
//

import UIKit
import MapKit
import CoreLocation
import SDWebImage
import Firebase


class DetailViewController: UIViewController, MKMapViewDelegate {
    
    @IBOutlet weak var userName: UILabel!
    @IBOutlet weak var likeButton : UIButton!
    @IBOutlet weak var dpImage: Custom_ImageView!
    @IBOutlet weak var productImage: Custom_ImageView!
    @IBOutlet weak var descriptionLabel: UITextField!
    @IBOutlet weak var mapView: MKMapView!
    
    var likeStatus = false
    var productDetail : Product_Distance!
    var userInfo : Profile?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        self.navigationController?.isNavigationBarHidden = true
        getUserInfo()
        dpImage.isUserInteractionEnabled = true
        
        let tap = UITapGestureRecognizer(target: self, action: #selector(GetDetail))
        dpImage.addGestureRecognizer(tap)
    }
    
    
    override func viewWillAppear(_ animate:Bool) {
        super.viewWillAppear(animate)
        
        // Do any additional setup after loading the view.
        self.navigationController?.isNavigationBarHidden = true
        getUserInfo()
    }
    
    
    @objc func GetDetail() {
        let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "USER") as! ProfileDetailVC
        
        vc.userid = productDetail.createdID
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @objc func seeFullImage() {
        let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "Large") as! LargeImageViewController
        
        vc.detail = productDetail
        self.navigationController!.pushViewController(vc, animated: true)
    }
    
    
    func getUserInfo() {
        let vm = FirebaseViewModel()
        vm.getUserProfile(id: productDetail.createdID) { [self] profile, Status, errorMsg in
            
            if Status {
                self.userName.text = (profile?.name)
                let url = URL(string:(profile!.image)!)
                self.dpImage.sd_setImage(with: url, placeholderImage: nil, options: .progressiveLoad)
                
                let url2 = URL(string:(self.productDetail!.image))
                self.productImage.sd_setImage(with: url2, placeholderImage: nil, options: .progressiveLoad)
                self.productImage.isUserInteractionEnabled = true
                let tap = UITapGestureRecognizer(target: self, action: #selector(self.seeFullImage))
                self.productImage.addGestureRecognizer(tap)
                self.descriptionLabel.text = self.productDetail.description
                
                let annotations = MKPointAnnotation()
                
                annotations.coordinate = CLLocationCoordinate2D(latitude: self.productDetail.lat, longitude: self.productDetail.long)
                let spanRegion = MKCoordinateSpan(latitudeDelta: 0.0025, longitudeDelta: 0.0025)
                annotations.title = "Seller: ' \(self.productDetail.createdBy)' "
                annotations.subtitle = "Product title:\(self.productDetail.name)"
                let mapRegion = MKCoordinateRegion(center: annotations.coordinate, span: spanRegion)
                self.mapView.addAnnotation(annotations)
                self.mapView.setRegion(mapRegion, animated: true)
                
            }
        }
    }
    
    
    
    @IBAction func backBtnAction(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    
    @IBAction func directionBtnAction(_ sender: Any) {
        //..
    }
    
    @IBAction func likeBtnAction(_ sender: Any) {
        if self.likeStatus == false {
            likeButton.setImage(UIImage(systemName:"hand.thumbsup.fill"), for: .normal)
            likeStatus = true
        } else {
            likeButton.setImage(UIImage(systemName:"hand.thumbsup"), for: .normal)
            likeStatus = false
        }
    }
    
    @IBAction func shareBtnAction(_ sender: Any) {
        let items = ["Product found in AlSouq: \(productDetail.name)"]
        let ac = UIActivityViewController(activityItems: items, applicationActivities: nil)
        present(ac, animated: true)
    }
    
    @IBAction func msgBtnAction(_ sender: Any) {
        let chatVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "Chat") as! ConversationVC
        chatVC.currentUser = Sender(senderId: userUUID, displayName: (currentUserProfile?.name)!)
        chatVC.otherUser = Sender(senderId: productDetail.createdID, displayName: productDetail.createdBy)
        self.navigationController?.pushViewController(chatVC, animated: true)
    }
    
    
    @IBAction func ratebtnAction(_ sender: Any) {
        performSegue(withIdentifier: "rate", sender: nil)
    }
    
    
    @IBAction func callBtnAction(_ sender: Any) {
        guard let number = URL(string: "tel://" + "09962123123") else { return }
        UIApplication.shared.open(number)
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "rate" {
            let dest = segue.destination as! RateVC
            dest.product = productDetail
        } else if  segue.identifier == "Full" {
            let dest = segue.destination as! FullMapVC
            dest.dest = CLLocationCoordinate2D(latitude: productDetail.lat, longitude: productDetail.long)
        }
    }
}

